package com.example.getpolelocation2;

import androidx.fragment.app.FragmentActivity;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(23.1815, 79.9864);
       mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Jabalpur"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        DataHelper mPoleDatabase=new DataHelper(this);
        Cursor cursorEmployees = mPoleDatabase.getAllPoles();
        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.color(Color.RED);
        polylineOptions.width(5);
       if(cursorEmployees.moveToFirst()) {
            do {
               // polesName=polesName + "\n" + cursorEmployees.getString(12)+cursorEmployees.getString(0) + " " + getDescription(cursorEmployees.getInt(4))+"UpLoaded " + cursorEmployees.getInt(11)+" Lat " + cursorEmployees.getDouble(9)+"Long " + cursorEmployees.getString(10);
                // Toast.makeText(this, "hai" +  cursorEmployees.getString(0) + "\n", Toast.LENGTH_SHORT).show();
                //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
                polylineOptions.add(new LatLng(cursorEmployees.getInt(9),cursorEmployees.getInt(10)));
              //  LatLng  i = new LatLng(cursorEmployees.getInt(9),cursorEmployees.getInt(10));
             //   mMap.addMarker(new MarkerOptions().position(i).title("Survey Point"));
               // mMap.moveCamera(CameraUpdateFactory.newLatLng(i));
            }
            while (cursorEmployees.moveToNext());
        };
        googleMap.addPolyline(polylineOptions);

        ////
       /* Polyline polyline1 = googleMap.addPolyline(new PolylineOptions());

                .clickable(true)

                .add(
                        new LatLng(-35.016, 143.321),
                        new LatLng(-34.747, 145.592),
                        new LatLng(-34.364, 147.891),
                        new LatLng(-33.501, 150.217),
                        new LatLng(-32.306, 149.248),
                        new LatLng(-32.491, 147.309))
        );*/

        // Position the map's camera near Alice Springs in the center of Australia,
        // and set the zoom factor so most of Australia shows on the screen.
      //  googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-23.684, 133.903), 4));

        // Set listeners for click events.
      //  googleMap.setOnPolylineClickListener(this);
      //  googleMap.setOnPolygonClickListener(this);

        ////
    }
}
