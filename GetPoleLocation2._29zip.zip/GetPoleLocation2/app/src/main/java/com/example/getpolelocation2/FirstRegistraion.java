package com.example.getpolelocation2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
public class FirstRegistraion extends AppCompatActivity {
    String lat_insert = "aditya";
    String long_insert = "123";
    String returnString="";
    String json = "";
    String result = "";
    Button submitBtn;
    EditText editUserName,editPassword;
    Context context;
    String sUsername="";
    String sPassword="";
    String userNameJSON="";
    String userPasswordJSON="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_registraion);

        ////
        context=getApplicationContext();
        submitBtn=findViewById(R.id.submitBtn);
        editUserName= (EditText)findViewById(R.id.editUserName);
        editPassword= (EditText)findViewById(R.id.editPassword);
        TextView textMessage=findViewById(R.id.textMessage);
        sUsername = editUserName.getText().toString();
        Toast.makeText(this,"Welcome",Toast.LENGTH_SHORT).show();
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sUsername = editUserName.getText().toString();
                Toast.makeText(context, sUsername,Toast.LENGTH_LONG);
                if (TextUtils.isEmpty(sUsername)) {
                    TextView textMessage=findViewById(R.id.textMessage);
                    textMessage.setText("Please Provide User Name ");
                    Toast.makeText(context,"User Name is Empty",Toast.LENGTH_LONG).show();
                    return;
                }

                sPassword = editPassword.getText().toString();
                Toast.makeText(context, sPassword,Toast.LENGTH_LONG);
                if (TextUtils.isEmpty(sPassword)) {
                    TextView textMessage=findViewById(R.id.textMessage);
                    textMessage.setText("Please Provide User Password");
                    Toast.makeText(context,"Password is  Empty",Toast.LENGTH_LONG).show();
                    return;
                }

                if(checkUser(sUsername,sPassword)) {

                    Toast.makeText(context,"8.User is Valid",Toast.LENGTH_LONG).show();
                    //Code Should be called here for JSON
                    lat_insert=sUsername;
                    long_insert=sPassword;
                    JSONObject jsonResponse;
                   new returnJSON1().execute(lat_insert,long_insert);
                    Toast.makeText(context, userNameJSON,Toast.LENGTH_LONG).show();
                  //  new returnJSON1().execute(sUsername,sPassword);
                    ///


                    ////// End of JSON Code

                    // Display and Validate JSON Data Here
                   // TextView   textMessage=findViewById(R.id.  textMessage);
                  //  textMessage.setText("JSON Data");
                    ///
                }
                else{
                    Toast.makeText(context,"9.Username or Password  is InValid",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    public boolean checkUser(String userName, String password){
        context=getApplicationContext();
        DataHelper dataHelper=new DataHelper(context);
        if(dataHelper.isValidUser(userName,password))
        {
            Toast.makeText(context,"1.Valid User and already Regsitered with Feeder",Toast.LENGTH_LONG).show();
            return  true;
        }
        else {
            Toast.makeText(context, "2. User Name or Password or No Feeder is alloted..Please wait we r checking with Server", Toast.LENGTH_LONG).show();
            // Here it must be checked if user exists in Web Server Data base or not
            //if exists in web server db only then insert
            /// web check method
            lat_insert = userName;
            long_insert = password;

            Toast.makeText(context, "3. Please wait  we r checking with Server the user "+ lat_insert, Toast.LENGTH_LONG).show();
            JSONObject jsonResponse;
            new returnJSON1().execute(lat_insert, long_insert);

            Toast.makeText(context, "4. checkedwith Server the user "+ lat_insert + "Found user name "+userNameJSON, Toast.LENGTH_LONG).show();


            if (TextUtils.isEmpty(userNameJSON)){
                Toast.makeText(context, "5. You are Not Registered with MPPKVVCL Server.First Register with Department for conducting Survey" + userNameJSON, Toast.LENGTH_LONG).show();
                return  false;

            }

        else
            {
                Toast.makeText(context,"6. Your Details Exists and Registered  in MPPKVVCL Database Server , Now Registering in App for Feeder Assignment",Toast.LENGTH_LONG).show();

                dataHelper.insertUsers(101,userName,userName,password);
                  }
            ///
           // dataHelper.insertUsers(101,userName,userName,password);
            Toast.makeText(context,"7. Now You Are Registered  in Database",Toast.LENGTH_LONG).show();
        }
        if(
                (
                               userName.equals("aditya") && password.equals("123")
                                || userName.equals("mamta") && password.equals("123")
                                || userName.equals("DNDR") && password.equals("123")
                                || userName.equals("shubham") && password.equals("123")
                                || userName.equals("agent") && password.equals("123")

                )


        )
            return  true;
        else
         //  return false;
            return  true;
    }
///////24.8
    private class returnJSON1 extends AsyncTask<String ,String ,String> {
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        TextView   textMessage=findViewById(R.id.  textMessage);

        JSONObject jsonResponse;
        try {
            jsonResponse = new JSONObject(result);
            JSONArray movies = jsonResponse.getJSONArray("Survey");
           // textMessage.setText(movies.length());
            for (int i = 0; i < movies.length(); i++) {
                JSONObject movie = movies.getJSONObject(i);
                String val1 = movie.getString("SURV_NAM");
                String val2 = movie.getString("USER_NAME");
                String val3 = movie.getString("FDR_NAME");
                String val4 = movie.getString("LONG_NAME");
                int val5 = movie.getInt("FEEDER_ID");
                String val6 = movie.getString("SS_33_11_KV_ID");
              //  String val7 = movie.getString("FDR_ASSIGN_ID");
                int val7=movie.getInt("FDR_ASSIGN_ID");
                String val8 = movie.getString("USER_PWD");
                //26.8
                userNameJSON=val1;
                //
                String allval="Surveyor ->" + val1 + "- User Name->  " +  val2 +   "-Feeder-> "+ val3+ "-Substation->   "+ val4
                        + "Feeder id" + val5 + "Substation id" + val6;
                if (TextUtils.isEmpty(val1)){
                    allval="98.No Feeder Alloted or User Name Password incorrect";
                }


                textMessage.setText(allval);
                Toast.makeText(context, "99. checkedwith Server the user "+ lat_insert + "Found user name "+userNameJSON, Toast.LENGTH_LONG).show();
                context=getApplicationContext();
                DataHelper dataHelper=new DataHelper(context);

                if (val7==0){
                    Toast.makeText(context, "#####991.  Feeder not allted checkedwith Server the user "+ lat_insert + "Found user name "+userNameJSON, Toast.LENGTH_LONG).show();
                }
                else {
                  //  dataHelper.insertUsers(101, val1, val2, val3);
                    dataHelper.insertUsers_27(101, val3, val2, val8,val5);
                    Toast.makeText(context, "101.Congratulations You have Registered with App also. checkedwith Server the user " + lat_insert + "Found user name  " + userNameJSON, Toast.LENGTH_LONG).show();
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
        protected String doInBackground(String... params) {
            String lat_insert = params[0];
            String long_insert = params[1];
            String register_url = "http://mpezgis.in/assets/surveyorInfo3.php";
            try {
                URL url = new URL(register_url);
                try {
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);

                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String post_data = URLEncoder.encode("lat", "UTF-8") + "=" + URLEncoder.encode(lat_insert, "UTF-8") + "&"
                            + URLEncoder.encode("lng", "UTF-8") + "=" + URLEncoder.encode(long_insert, "UTF-8");
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    String line = "";
                    while ((line = bufferedReader.readLine()) != null) {
                        result += line;

                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;

                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    //24.8
}


