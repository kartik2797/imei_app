package com.example.getpolelocation2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.AvailableNetworkInfo;
import android.view.Gravity;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class DataUpLoad extends AppCompatActivity {
    protected Context context;
    InputStream is = null;
    String result = null;
    String line = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_up_load);
        context = getApplicationContext();
        Toast.makeText(context," Uploading Data",Toast.LENGTH_LONG).show();
       // listPoles=findViewById(R.id.textPoles);
        final DataHelper mPoleDatabase=new DataHelper(this);
        Cursor cursorEmployees = mPoleDatabase.getAllPoles();
       // mPoleDatabase.upDateRecordUpload("1");
        String polesName="nnnnnn";
        //Toast.makeText(this,polesName,Toast.LENGTH_LONG).show();
        /////////
        /////
      //  new loadData().execute("2300","34989");
       // Toast.makeText(this,"After Insertion",Toast.LENGTH_LONG).show();
        ////////
       Toast myToast=new Toast(this);
        int recCnt=1;
        if(cursorEmployees.moveToFirst()) {
            do {
                polesName=polesName + "\n" + cursorEmployees.getString(0) + "Latitude " + cursorEmployees.getDouble(9)+"Longitude "+ cursorEmployees.getString(10);
             //   Toast.makeText(this, "hai" +  cursorEmployees.getString(0) + "\n", Toast.LENGTH_SHORT).show();
              //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
              // new LoadData.execute(cursorEmployees.getDouble(9),cursorEmployees.getDouble(10));
// Add code to check Network Here
                //if Network is available then only fire load data


 //
              new loadData().execute(
                      Integer.toString(cursorEmployees.getInt(1)), Integer.toString(cursorEmployees.getInt(2)), Integer.toString(cursorEmployees.getInt(3)),
                      Integer.toString(cursorEmployees.getInt(4)), Integer.toString(cursorEmployees.getInt(5)), Integer.toString(cursorEmployees.getInt(6)),
                      Integer.toString(cursorEmployees.getInt(7)),  Integer.toString(cursorEmployees.getInt(8)),
                      Double.toString(cursorEmployees.getDouble(9)),
                      Double.toString(cursorEmployees.getDouble(10)),
                      Integer.toString(cursorEmployees.getInt(0))
              )
              ;
              //  new loadData().execute("1","2","3","4","5","6","7","8","9","10");
                myToast.setGravity(Gravity.CENTER,0,0);
                myToast.makeText(this, Integer.toString(recCnt)+" Record(s) uploaded",Toast.LENGTH_SHORT).show();
                mPoleDatabase.upDateRecordUpload(cursorEmployees.getInt(0));
                recCnt++;
              //  new loadData().execute("2300","34989");
            }
            while (cursorEmployees.moveToNext());
           // myToast.makeText(this, Integer.toString(recCnt)+" Total  Record(s) uploaded ",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this,"No Record",Toast.LENGTH_SHORT).show();
        }
       // Toast.makeText(this,polesName,Toast.LENGTH_LONG).show();
       // listPoles.setText(polesName);

        //////////
    }

    public static boolean isNetworkAvailable(Context context)
    {
        ConnectivityManager connectivity =(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(connectivity !=null )
        {
         return true;
            //AvailableNetworkInfo[] info=connectivity.getAllNetworkInfo();
        }
        return  false;
    }
}



class loadData extends AsyncTask <String ,String ,String>{

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

       // Toast.makeText(this, "Start", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
    }
///////// 19.8
    @Override
    protected String doInBackground(String... params) {
        // String type = params[0];
       // String lat_insert = params[0];
      //  String long_insert = params[1];
        /*
        //Data upload Parameters for lat long and other para
*/
        String FDR_ID = params[0];
        String SUB_ID = params[1];
        String POLE_TYP = params[2];
        String SUPP_TYP = params[3];
        String COND_TYP = params[4];
        String DTR_CAP = params[5];
        String AB_SWITCH = params[6];
        String DTR_METERED = params[7];
        String POLE_LAT = params[8];
        String POLE_LONG = params[9];
        String DEV_POLE_ID = params[10];

        //  String register_url = " http://www.mpezgis.in/mpezgis.in/mpez/test/test72.php";
     // String register_url = "http://www.mpezgis.in/mpezgis.in/mpez/test/insertlatlong.php";
       String register_url = "http://www.mpezgis.in/assets/InsertFDR.php";

        // Toast.makeText(getApplicationContext(), "working", Toast.LENGTH_LONG).show();
        //  if (type.equals("register")) {
        try {
            URL url = new URL(register_url);
            try {

                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);

                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
             // 19  String post_data = URLEncoder.encode("lat", "UTF-8") + "=" + URLEncoder.encode(lat_insert, "UTF-8") + "&"
              // 19         + URLEncoder.encode("lng", "UTF-8") + "=" + URLEncoder.encode(long_insert, "UTF-8");
                String post_data = URLEncoder.encode("FDR_ID", "UTF-8") + "=" + URLEncoder.encode(FDR_ID, "UTF-8") + "&"
                + URLEncoder.encode("SUB_ID", "UTF-8") + "=" + URLEncoder.encode(SUB_ID, "UTF-8") + "&"
                + URLEncoder.encode("POLE_TYP", "UTF-8") + "=" + URLEncoder.encode(POLE_TYP, "UTF-8") + "&"
                + URLEncoder.encode("SUPP_TYP", "UTF-8") + "=" + URLEncoder.encode(SUPP_TYP, "UTF-8") + "&"
                + URLEncoder.encode("COND_TYP", "UTF-8") + "=" + URLEncoder.encode(COND_TYP, "UTF-8") + "&"
                + URLEncoder.encode("DTR_CAP", "UTF-8") + "=" + URLEncoder.encode(DTR_CAP, "UTF-8") + "&"
                + URLEncoder.encode("AB_SWITCH", "UTF-8") + "=" + URLEncoder.encode(AB_SWITCH, "UTF-8") + "&"
                + URLEncoder.encode("DTR_METERED", "UTF-8") + "=" + URLEncoder.encode(DTR_METERED, "UTF-8") + "&"
                + URLEncoder.encode("POLE_LAT", "UTF-8") + "=" + URLEncoder.encode(POLE_LAT, "UTF-8") + "&"
               + URLEncoder.encode("POLE_LONG", "UTF-8") + "=" + URLEncoder.encode(POLE_LONG, "UTF-8")
               + URLEncoder.encode("DEV_POLE_ID", "UTF-8") + "=" + URLEncoder.encode(DEV_POLE_ID, "UTF-8")

                ;
               // post_data=trim(pos)

                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;

                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return result;
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }


        //  } // String register_url=".php";
        return null;
    }
    ////////////// 19.8
}




