package com.example.getpolelocation2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class ListPoles extends AppCompatActivity {
    TextView listPoles;
    protected Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_poles);
        context = getApplicationContext();
         Toast.makeText(context," From Poles Lis",Toast.LENGTH_LONG).show();
        listPoles=findViewById(R.id.textPoles);
        final DataHelper mPoleDatabase=new DataHelper(this);
       // Cursor c=mPoleDatabase.getAllPoles();
        Cursor cursorEmployees = mPoleDatabase.getAllPoles();
        String polesName="nnnnnn";
        Toast.makeText(this,polesName,Toast.LENGTH_LONG).show();
        listPoles.setText(polesName);

        /////////

        if(cursorEmployees.moveToFirst()) {
            do {
                polesName=polesName + "\n" + cursorEmployees.getString(12)+cursorEmployees.getString(0) + " " + getDescription(cursorEmployees.getInt(4))+"UpLoaded " + cursorEmployees.getInt(11)+" Lat " + cursorEmployees.getDouble(9)+"Long " + cursorEmployees.getString(10);
               // Toast.makeText(this, "hai" +  cursorEmployees.getString(0) + "\n", Toast.LENGTH_SHORT).show();
              //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
            }
            while (cursorEmployees.moveToNext());
        }
        else{
            Toast.makeText(this,"No Record",Toast.LENGTH_SHORT).show();
        }
        Toast.makeText(this,polesName,Toast.LENGTH_LONG).show();
        listPoles.setText(polesName);

        //////////
    }


    public String getDescription(int rCode){
        String desCription="";
        switch(rCode){
            case 0:
                desCription="H BEAM";
                break;
                //Do this and this        break;
            case 1:
                desCription="OTHER";
                break;
                //Do this and this            // /break;
            case 2:
                desCription="j BEAM";
                //Do this and this:
                break;
            default: //For all other cases, do this        break;
        }
        return desCription;
    }
}
