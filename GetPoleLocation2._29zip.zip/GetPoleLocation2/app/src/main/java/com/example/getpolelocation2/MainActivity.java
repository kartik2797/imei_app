package com.example.getpolelocation2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button surv,showPole,upLoadData,btnReg;
    protected Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        surv=findViewById(R.id.button);
        showPole=findViewById(R.id.buttonPole);
       btnReg=findViewById(R.id.btnReg);
        //upLoadData=findViewById(R.id.buttonUpLoad);
        /////
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context=getApplicationContext();
                Toast.makeText(context,"First Register",Toast.LENGTH_LONG).show();
                Intent regInetent=new Intent(MainActivity.this,FirstRegistraion.class);
                MainActivity.this.startActivity(regInetent);
            }
        });

        showPole.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t1=findViewById(R.id.t1);
                t1.setText("Showing Poles");
             //    Toast.makeText(context," Permssions After",Toast.LENGTH_LONG).show();
               Intent myIntentPole = new Intent(MainActivity.this, ListPoles.class);

               MainActivity.this.startActivity(myIntentPole);
               // Intent myIntent = new Intent(MainActivity.this, PoleSurvey.class);

               // MainActivity.this.startActivity(myIntent);
            }
        });

        //////
       /* upLoadData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, DataUpLoad.class);

                MainActivity.this.startActivity(myIntent);
            }
        });*/
        /////////24.8
            /*  btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context," First complete Registraion",Toast.LENGTH_LONG).show();

              //  Intent myIntent = new Intent(MainActivity.this, FirstRegistraion.class);

               // MainActivity.this.startActivity(myIntent);
            }
        });*/
        ////////

        surv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Intent myIntent = new Intent(MainActivity.this, PoleSurvey.class);
                Intent myIntent = new Intent(MainActivity.this, SurveyLogin.class);

                MainActivity.this.startActivity(myIntent);
            }
        });
    }

   /* public void regsiterFdr(View view){
        //Toast.makeText(context," First complete Registraion",Toast.LENGTH_LONG).show();
        Intent myReg = new Intent(MainActivity.this, FirstRegistraion.class);
        MainActivity.this.startActivity(myReg);
    }*/
}
