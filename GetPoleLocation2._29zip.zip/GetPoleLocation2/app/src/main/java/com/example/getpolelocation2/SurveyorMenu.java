package com.example.getpolelocation2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SurveyorMenu extends AppCompatActivity {
Button startSurvey,viewListofPoles,DataUpLoad,ViewMap;
    Bundle b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_surveyor_menu);
        startSurvey=findViewById(R.id.startSurvey);
        viewListofPoles=findViewById(R.id.viewListofPoles);
        DataUpLoad=findViewById(R.id.DataUpLoad);
        ViewMap=findViewById(R.id.ViewMap);
         b1=getIntent().getExtras();

        Toast.makeText(this,b1.getString("feedername"),Toast.LENGTH_LONG).show();

        startSurvey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b2=new Bundle();
                b2.putString("feedername",b1.getString("feedername"));
                b2.putString("substation",b1.getString("substation"));
                b2.putInt("feederID",b1.getInt("feederID"));

                Intent myIntent = new Intent(SurveyorMenu.this, PoleSurvey.class);
                myIntent.putExtras(b2);
                SurveyorMenu.this.startActivity(myIntent);
            }
        });

        viewListofPoles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntentPole = new Intent(SurveyorMenu.this, ListPoles.class);

                SurveyorMenu.this.startActivity(myIntentPole);
            }
        });

        ViewMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SurveyorMenu.this,MapsActivity.class);
                startActivity(intent);
            }
        });

        DataUpLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(SurveyorMenu.this, DataUpLoad.class);

                SurveyorMenu.this.startActivity(myIntent);
            }
        });
    }
}
