package com.example.getpolelocation2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SurveyLogin extends AppCompatActivity {
    Button submitBtn;
    EditText editUserName,editPassword;
    Context context;
    String sUsername="";
    String sPassword="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey_login);
        context=getApplicationContext();
        submitBtn=findViewById(R.id.submitBtn);
        editUserName= (EditText)findViewById(R.id.editUserName);
        editPassword= (EditText)findViewById(R.id.editPassword);
        TextView textMessage=findViewById(R.id.textMessage);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //String value = text.getText().toString();
                sUsername = editUserName.getText().toString();
                Toast.makeText(context, sUsername,Toast.LENGTH_LONG);
                if (TextUtils.isEmpty(sUsername)) {
                    TextView textMessage=findViewById(R.id.textMessage);
                    textMessage.setText("Please Provide User Name ");
                    Toast.makeText(context,"User Name is Empty",Toast.LENGTH_LONG).show();
                    return;
                }

                sPassword = editPassword.getText().toString();
                Toast.makeText(context, sPassword,Toast.LENGTH_LONG);
                if (TextUtils.isEmpty(sPassword)) {
                    TextView textMessage=findViewById(R.id.textMessage);
                    textMessage.setText("Please Provide User Password");
                    Toast.makeText(context,"Password is  Empty",Toast.LENGTH_LONG).show();
                    return;
                }
                // if(checkUser( sUsername, sPassword)){
                if(checkUser(sUsername,sPassword)) {
                    // code to check from database also

                    Bundle b1=new Bundle();
                    b1.putString("feedername",feederName(sUsername));
                    b1.putString("substation","");
                    b1.putInt("feederID",feederID(sUsername));
                    Intent myIntent = new Intent(SurveyLogin.this, SurveyorMenu.class);
                    myIntent.putExtras(b1);
                    SurveyLogin.this.startActivity(myIntent);
                }
            }
        });
    }

    public String feederName(String userName){
        String FeederName="";
        context=getApplicationContext();
        DataHelper dataHelper=new DataHelper(context);
       FeederName=dataHelper.getAllottedFeeder(userName);

        Toast.makeText(this, "Allotted Feeder" + FeederName + "\n", Toast.LENGTH_SHORT).show();
        return FeederName;

    }

    public int feederID(String userName){
        int Feeder_id=0;
        context=getApplicationContext();
        DataHelper dataHelper=new DataHelper(context);
        Feeder_id=dataHelper.getAllottedFeeder_id(userName);

        //Toast.makeText(this, "Allotted Feeder" + FeederName + "\n", Toast.LENGTH_SHORT).show();
        return Feeder_id;

    }
    //////////////////////////
    public boolean checkUser(String userName, String password){

        context=getApplicationContext();
        DataHelper dataHelper=new DataHelper(context);
        Cursor c=dataHelper.getUser(userName,password);
        if(c.moveToFirst()) {
            do {
                //Name=polesName + "\n" + cursorEmployees.getString(0) + " " + getDescription(cursorEmployees.getInt(4))+"UpLoaded " + cursorEmployees.getInt(11)+" Lat " + cursorEmployees.getDouble(9)+"Long " + cursorEmployees.getString(10);
                 Toast.makeText(this, "hai" +  c.getString(0) + "\n", Toast.LENGTH_SHORT).show();
                 String s=c.getString(0);
                //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
            }
            while (c.moveToNext());
        }

        if(dataHelper.isValidUser(userName,password))
        {
            Toast.makeText(context,"Valid User name and Password Please Start/Resume the Survey",Toast.LENGTH_LONG).show();
            return  true;
        }
        else{
            Toast.makeText(context,"User Name does Not Exists or No Feeder is alloted .Please Check and Try Again",Toast.LENGTH_LONG).show();
            return false;
        }
    /*   if(
                (
                userName.equals("aditya") && password.equals("123")
                || userName.equals("mamta") && password.equals("123")
               || userName.equals("DNDR") && password.equals("123")
               || userName.equals("shubham") && password.equals("123")
               || userName.equals("agent") && password.equals("123")


                )


        )
            return  true;
        else
            return false; */
    }
}
