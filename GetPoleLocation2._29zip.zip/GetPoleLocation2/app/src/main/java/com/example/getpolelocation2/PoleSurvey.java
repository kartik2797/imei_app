package com.example.getpolelocation2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.util.Log;
import android.widget.Toast;

public class PoleSurvey extends AppCompatActivity implements LocationListener {
    TextView txtLat,textFeeder,sup_struct,txt_typ_stc,txt_dtr_p,txt_cond_t,txt_ab_switch,txt_dtr_mtr,txt_exp_imp,txt_end_point;
    protected LocationManager locationManager;
    protected LocationListener locationListener;
    protected Context context;
    String lat;
    String provider;
    protected String latitude, longitude;
    protected boolean gps_enabled, network_enabled;
    private static final int LOCATION_REQUEST_CODE = 101;
    Spinner fdr_11, fdr_33, supp_stc, typ_stc, dtr_p, cond_t,ab_switch,dtr_metered,end_point,exp_imp_pt,tp_point;
    Button submit;
    Double PoleLat,PoleLong;
    Bundle bFeeder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pole_survey);
        bFeeder=getIntent().getExtras();
        Toast.makeText(this,"Assigned Feeder ID is " + bFeeder.getInt("feederID"),Toast.LENGTH_LONG).show();
       // Toast.makeText(this,"Assigned Feeder is " + bFeeder.getString("feedername"),Toast.LENGTH_LONG).show();
        textFeeder = findViewById(R.id.textFeeder);
        textFeeder.setText("33KV Substation->" + bFeeder.getString("substation") + "\n" +" 11KV Feeder ->"+ bFeeder.getString("feedername"));
        txtLat = findViewById(R.id.textView);
        txtLat.setText("Fetching Lat Long");

        // Visuals Section
        txt_typ_stc=findViewById(R.id.txt_typ_stc);
        txt_ab_switch=findViewById(R.id.txt_ab_switch);
        txt_dtr_mtr=findViewById(R.id.txt_dtr_mtr);
        txt_dtr_p=findViewById(R.id.txt_dtr_p);
        txt_exp_imp=findViewById(R.id.txt_exp_imp);
        txt_end_point=findViewById(R.id.txt_end_point);
      /*  sup_struct=findViewById(R.id.sup_struct);
        txt_typ_stc=findViewById(R.id.txt_typ_stc);
        txt_dtr_p=findViewById(R.id.txt_dtr_p);
        txt_cond_t=findViewById(R.id.txt_cond_t);*/
      /*  fdr_11 = findViewById(R.id.fdr_11);
        ArrayAdapter< CharSequence > adapter1 = ArrayAdapter.createFromResource(this,
                R.array.fdr_11, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fdr_11.setAdapter(adapter1);

        fdr_33 = findViewById(R.id.fdr_33);
        ArrayAdapter< CharSequence > adapter2 = ArrayAdapter.createFromResource(this,
                R.array.fdr_33, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fdr_33.setAdapter(adapter2);*/
///
        supp_stc = findViewById(R.id.supp_stc);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.supp_stc, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        supp_stc.setAdapter(adapter3);
//
//////
        typ_stc = findViewById(R.id.typ_stc);
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,
                R.array.typ_stc, android.R.layout.simple_spinner_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typ_stc.setAdapter(adapter4);
        ///////

        /////////
        dtr_p = findViewById(R.id.dtr_p);
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,
                R.array.dtr_p, android.R.layout.simple_spinner_item);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dtr_p.setAdapter(adapter5);
        /////////
/////////
        cond_t = findViewById(R.id.cond_t);
        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this,
                R.array.cond_t, android.R.layout.simple_spinner_item);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cond_t.setAdapter(adapter6);

        ab_switch=findViewById(R.id.ab_switch);
        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(this,
                R.array.ab_switch, android.R.layout.simple_spinner_item);
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ab_switch.setAdapter(adapter7);

        dtr_metered=findViewById(R.id.dtr_metered);
        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(this,
                R.array.dtr_metered, android.R.layout.simple_spinner_item);
        adapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dtr_metered.setAdapter(adapter8);

        end_point=findViewById(R.id.end_point);
        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(this,
                R.array.end_point, android.R.layout.simple_spinner_item);
        adapter9.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        end_point.setAdapter(adapter9);

        exp_imp_pt=findViewById(R.id.exp_imp_pt);
        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(this,
                R.array.exp_imp_pt, android.R.layout.simple_spinner_item);
        adapter10.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        exp_imp_pt.setAdapter(adapter10);

        tp_point=findViewById(R.id.tp_point);
        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(this,
                R.array.tp_point, android.R.layout.simple_spinner_item);
        adapter11.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tp_point.setAdapter(adapter11);


        ////////////
       // supp_stc.setAdapter(adapter3);
        submit = findViewById(R.id.btn2);
        // Visual Section Ends


        context = getApplicationContext();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Toast.makeText(context, "App is Checking GPS Permissons", Toast.LENGTH_SHORT).show();

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "Please Provide GPS Permission to Use This App", Toast.LENGTH_SHORT).show();
           // myD(this.findViewById(R.id.submit));
            ActivityCompat.requestPermissions(this, new String[] {
                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_REQUEST_CODE);
           // Toast.makeText(context," Permssions After",Toast.LENGTH_LONG).show();
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             //   myD(view);
                Toast.makeText(context, "Saving the Record Please Wait...", Toast.LENGTH_SHORT).show();
               // submit.setBackgroundColor(255);
                submit.setVisibility(View.GONE);
                submit.setEnabled(false);
                DataHelper dataHelper=new DataHelper(context);
             //   dataHelper.insertProvince("PATAN111");

                /////////
               // int fdr=fdr_11.getSelectedItemPosition();
               // int fdr33=fdr_33.getSelectedItemPosition();
                int fdr=bFeeder.getInt("feederID");
                int fdr33=100;
                int suptextPos=supp_stc.getSelectedItemPosition();
                int typ_stc1=typ_stc.getSelectedItemPosition();
                int dtr=dtr_p.getSelectedItemPosition();
                int cond=cond_t.getSelectedItemPosition();
               // dataHelper.insertProvince("PATAN111");
                /////check if lat or long are nu null
              if(PoleLat != null) {
                    dataHelper.insertProvince1(fdr, fdr33, suptextPos, typ_stc1, dtr, cond, PoleLat, PoleLong);
                    Toast.makeText(context, "Record has been Saved .Please Survey Another Location", Toast.LENGTH_LONG).show();
                    finish();
                }
                else
                {
                    //requestPermissions();
                    myD(view);
                    Toast.makeText(context, "Location Not Fetched, Please Set GPS on ", Toast.LENGTH_LONG).show();
                  //  finish();
                }

               submit.setVisibility(View.VISIBLE);
               submit.setEnabled(true);
              // submit.setBackgroundColor(255);
              // finish();

                ///////////
            }
        });
    }

    @Override
    public void onLocationChanged(Location location) {
        txtLat = findViewById(R.id.textView);
        Toast.makeText(context,"New Location Cordinates Recieved Please wait..",Toast.LENGTH_SHORT).show();
        txtLat.setText("Latitude:" + location.getLatitude() + ", Longitude:" + location.getLongitude());
        PoleLat=location.getLatitude();
        PoleLong=location.getLongitude();
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
///23.8
    public  void myD(View view){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert for Saving Pole Location");
        alertDialog.setMessage("Please provide GPS Permissions first and wait for Location Update ");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Toast.makeText(this,"OK Saving the Data",Toast.LENGTH_LONG).show();
                        //  sendsms(this);

                        dialog.dismiss();
                    }
                });

      /*  alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        dialog.dismiss();
                    }
                });*/

        alertDialog.show();
    }
    // 23.8
}
