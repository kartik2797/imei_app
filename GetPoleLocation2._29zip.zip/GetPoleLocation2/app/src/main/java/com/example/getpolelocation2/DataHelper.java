package com.example.getpolelocation2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DataHelper  extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "geoDB38";
    //  public static final String TABLE_PRO = "tblprovinces";
    public static final String TABLE_LOC = "MY_LOCATION";
    public static final String TABLE_PRO = "FDR_TBL_1";
    //public static final String TABLE_FDR = "FDR_TBL";
    public static final String TABLE_FDR = "FDR_TBL";
    public static final String TABLE_USER = "USER_TBL";
    ///
    private static  final String KEY_ID = "id";
    private static  final String KEY_FDR_ID = "FDR_ID";
    private static  final String KEY_SUB_ID = "SUB_ID";
    private static  final String KEY_POLE_TYP="POLE_TYP";
    private static  final String KEY_SUPP_TYP="SUPP_TYP";
    private static  final String KEY_COND_TYP="COND_TYP";
    private static  final String KEY_DTR_CAP="DTR_CAP";
    private static  final String KEY_AB_SWITCH="AB_SWITCH";
    private static  final String KEY_DTR_METERED="DTR_METERED";
    private static  final String KEY_POLE_LAT="POLE_LAT";
    private static  final String KEY_DPOLE_LONG="POLE_LONG";
    private static  final String KEY_UPDATE="STATUS";
    private static  final String KEY_DATE_TIME="DATETIME";

    private static  final String KEY_USER_NAME="USER_NAME";
    private static  final String KEY_USER_PASSWORD="USER_PASSWORD";
    private static  final String KEY_FEEDER_NAME="FEEDER_NAME";
  //  private static  final String KEY_FDR_ID="FDR_ID"; //already defined above


    ///

    public static final int DATABASE_VERSION = 1;
    public static final String CREATE_RPO = "CREATE TABLE IF NOT EXISTS " + TABLE_PRO + "(id INTEGER PRIMARY KEY AUTOINCREMENT, pname)";
    // public static final String CREATE_TABLE_FDR = "CREATE TABLE IF NOT EXISTS " + TABLE_FDR + "(id INTEGER PRIMARY KEY AUTOINCREMENT, FDR_ID INTEGER, SUBB_ID INTEGER, POLE_TYP INTEGER )";
    public static final String DELETE_PRO = "DROP TABLE IF EXISTS " + TABLE_PRO;
   // public static final String CREATE_TABLE_FDR = "CREATE TABLE IF NOT EXISTS " + TABLE_FDR + "(id INTEGER PRIMARY KEY AUTOINCREMENT, FDR_ID INTEGER, SUB_ID INTEGER, POLE_TYP INTEGER,SUPP_TYP INTEGER,COND_TYP INTEGER,DTR_CAP INTEGER,AB_SWITCH INTEGER,DTR_METERED INTEGER )";
 public static final String CREATE_TABLE_FDR = "CREATE TABLE IF NOT EXISTS " + TABLE_FDR + "(id INTEGER PRIMARY KEY AUTOINCREMENT, FDR_ID INTEGER, SUB_ID INTEGER, POLE_TYP INTEGER,SUPP_TYP INTEGER,COND_TYP INTEGER,DTR_CAP INTEGER,AB_SWITCH INTEGER,DTR_METERED INTEGER,POLE_LAT  DOUBLE,POLE_LONG DOUBLE, STATUS INTEGER, DATETIME DEFAULT CURRENT_TIMESTAMP)";

    public static final String CREATE_TABLE_USER = "CREATE TABLE IF NOT EXISTS " + TABLE_USER + "(id INTEGER PRIMARY KEY AUTOINCREMENT, USER_ID INTEGER,FEEDER_NAME TEXT,USER_NAME TEXT, USER_PASSWORD TEXT,FDR_ID INTEGER)";

   // public static final String INSERT_USER = "CREATE TABLE IF NOT EXISTS " + TABLE_USER + "(id INTEGER PRIMARY KEY AUTOINCREMENT, USER_ID INTEGER,FEEDER_NAME VARCHAR,USER_NAME VARCHAR, USER_PASSWORD VARCHAR)";

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_RPO);
        db.execSQL(CREATE_TABLE_FDR);
        db.execSQL(CREATE_TABLE_USER);
       //this.insertUsers(1,"11KV RAMPUR","ADITYA","123");
      ////  insertUsers(2,2,"IT PARK","MAMTA","123");
    //    insertUsers(3,3,"BALDEOBAG","DNDR","123");
       // insertUsers(4,"TTT","TEST FDR","123");


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public DataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase db = this.getWritableDatabase();
    }
public void upDateRecordUpload(int id){
      // String sel[]={id_for};
       String whereClause = "id"+" = "+id+" ";
       SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        ContentValues values;
    try{
        values = new ContentValues();
        //values.put("ID", id);
        values.put("STATUS",1);
        db.update(TABLE_FDR,values,whereClause,null);
      //  String updateQuery = "UPDATE FDR_TBL SET STATUS = 1 WHERE id = " + id_for ;
      //  db.execSQL(updateQuery);
       // db.update(TABLE_FDR,"ID=?",ID)
        db.setTransactionSuccessful();
    }
    catch (Exception e) {
        e.printStackTrace();

    } finally {
        db.endTransaction();
        // End the transaction.
        db.close();
        // Close database
    }
}
    public void insertProvince(String pname) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        ContentValues values;
        try {
            values = new ContentValues();
            values.put("pname", pname);
            // Insert Row
            db.insert(TABLE_PRO, null, values);
            // Insert into database successfully.
            db.setTransactionSuccessful();



        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database
        }
    }

    ////////
    public void insertProvince1(int fdr_id, int sub_id, int pole_typ, int supp_typ, int cond_typ, int dtr_cap ,double pole_lat,double pole_long) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        ContentValues values;
        try {
            values = new ContentValues();
            values.put("FDR_ID", fdr_id);
            values.put("SUB_ID", sub_id);
            values.put("POLE_TYP", pole_typ);
            values.put("SUPP_TYP", supp_typ);
            values.put("COND_TYP", cond_typ);
            values.put("DTR_CAP", dtr_cap);
            values.put("POLE_LAT", pole_lat);
            values.put("POLE_LONG", pole_long);
            values.put("STATUS", 0);
            //values.put("AB_SWITCH", ab_switch);
            //values.put("DTR_METERED", dtr_metered);
            // Insert Row
            db.insert(TABLE_FDR, null, values);
            // Insert into database successfully.
            db.setTransactionSuccessful();


        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database
        }
    }

    ///////////////

    /////////List Poles
    public Cursor getAllPoles() {
        SQLiteDatabase database = this.getWritableDatabase();
        String st="0";
        String []selarg={st};
      //  Cursor c = database.query("TABLE_FDR", new String[]{"FDR_ID", "SUB_ID"}, null, null, null, null, null);
         // Cursor c = database.query("FDR_TBL", new String[]{KEY_ID, KEY_FDR_ID, KEY_SUB_ID,KEY_POLE_TYP,KEY_SUPP_TYP,KEY_COND_TYP,KEY_DTR_CAP,KEY_AB_SWITCH,KEY_DTR_METERED,KEY_POLE_LAT,KEY_DPOLE_LONG,KEY_UPDATE}, null, null, null, null, null);
        Cursor c = database.query("FDR_TBL", new String[]{KEY_ID, KEY_FDR_ID, KEY_SUB_ID,KEY_POLE_TYP,KEY_SUPP_TYP,KEY_COND_TYP,KEY_DTR_CAP,KEY_AB_SWITCH,KEY_DTR_METERED,KEY_POLE_LAT,KEY_DPOLE_LONG,KEY_UPDATE,KEY_DATE_TIME}, KEY_UPDATE +"=?", selarg, null, null, null);

        if (c !=null) {
            c.moveToFirst();
        }
        return c;
    }

    //////////
    //User management Table and Methods
    public void insertUsers( int user_id , String feeder_name ,String user_name , String user_password) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        ContentValues values;
        try {
            values = new ContentValues();
            values.put("USER_ID", user_id);
           // values.put("FDR_ID", fdr_id);
            values.put("FEEDER_NAME",  feeder_name);
            values.put("USER_NAME", user_name);
            values.put("USER_PASSWORD",  user_password);

           // values.put("FDR_ID",  fdr_id);

            db.insert(TABLE_USER, null, values);
            // Insert into database successfully.
            db.setTransactionSuccessful();


        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database
        }
    }

    ////////
    public void insertUsers_27( int user_id , String feeder_name ,String user_name , String user_password,int fdr_id) {
        // Creation Data 28 August 2019
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        ContentValues values;
        try {
            values = new ContentValues();
            values.put("USER_ID", user_id);
            // values.put("FDR_ID", fdr_id);
            values.put("FEEDER_NAME",  feeder_name);
            values.put("USER_NAME", user_name);
            values.put("USER_PASSWORD",  user_password);

             values.put("FDR_ID",  fdr_id);

            db.insert(TABLE_USER, null, values);
            // Insert into database successfully.
            db.setTransactionSuccessful();


        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database
        }
    }

    /////////

    public boolean isValidUser(String user_name , String user_password){
        // Fetch from Database
        // if user exists return true or return false;
        Cursor userCnt=getUser(user_name,user_password);
        int userCount=0;
        if(userCnt.moveToFirst()) {
            do {
                //Name=polesName + "\n" + cursorEmployees.getString(0) + " " + getDescription(cursorEmployees.getInt(4))+"UpLoaded " + cursorEmployees.getInt(11)+" Lat " + cursorEmployees.getDouble(9)+"Long " + cursorEmployees.getString(10);
               // Toast.makeText(this, "hai" +  userCnt.getString(0) + "\n", Toast.LENGTH_SHORT).show();
                String s=userCnt.getString(0);
                userCount=userCount+1;
                //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
            }
            while (userCnt.moveToNext());
        }
      //  String u= userCnt.getString(0);
        if(userCount > 0 )
            return true;
        else
            return  false;

    }

    public Cursor getUser(String user_name , String user_password) {
        SQLiteDatabase database = this.getWritableDatabase();
        String whereClause = "USER_NAME"+" = "+user_name+" ";
        String st=user_name;
        String[] cols={KEY_USER_NAME,KEY_USER_PASSWORD};
        String []selarg={st};
     //   Cursor c = database.query("FDR_TBL", new String[]{KEY_ID, KEY_FDR_ID, KEY_SUB_ID,KEY_POLE_TYP,KEY_SUPP_TYP,KEY_COND_TYP,KEY_DTR_CAP,KEY_AB_SWITCH,KEY_DTR_METERED,KEY_POLE_LAT,KEY_DPOLE_LONG,KEY_UPDATE}, KEY_UPDATE +"=?", selarg, null, null, null);

        Cursor c = database.query("USER_TBL", new String[] {KEY_USER_NAME,KEY_USER_PASSWORD}, KEY_USER_NAME +"=?", selarg, null, null, null,null);
        if (c !=null ) {
            c.moveToFirst();
        }
        return c;
    }

    /// Feeder Name and Feeder id
    public String getAllottedFeeder(String user_name ){
        String feeder_name="";
        // Fetch from Database
        // if user exists return true or return false;
        Cursor userFDR=getUserFeeder(user_name);
        int fdrCnt=0;
        if(userFDR.moveToFirst()) {
            do {
                //Name=polesName + "\n" + cursorEmployees.getString(0) + " " + getDescription(cursorEmployees.getInt(4))+"UpLoaded " + cursorEmployees.getInt(11)+" Lat " + cursorEmployees.getDouble(9)+"Long " + cursorEmployees.getString(10);
                // Toast.makeText(this, "hai" +  userCnt.getString(0) + "\n", Toast.LENGTH_SHORT).show();
                feeder_name=feeder_name+userFDR.getString(2);
                fdrCnt=fdrCnt+1;
                //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
            }
            while (userFDR.moveToNext());
        }
        //  String u= userCnt.getString(0);
        if(fdrCnt > 0 )
            return feeder_name;
        else
            return  feeder_name;

    }

    public int getAllottedFeeder_id(String user_name ){
        int feeder_id=0;
        // Fetch from Database
        // if user exists return true or return false;
        Cursor userFDR=getUserFeeder(user_name);
        int fdrCnt=0;
        if(userFDR.moveToFirst()) {
            do {
                //Name=polesName + "\n" + cursorEmployees.getString(0) + " " + getDescription(cursorEmployees.getInt(4))+"UpLoaded " + cursorEmployees.getInt(11)+" Lat " + cursorEmployees.getDouble(9)+"Long " + cursorEmployees.getString(10);
                // Toast.makeText(this, "hai" +  userCnt.getString(0) + "\n", Toast.LENGTH_SHORT).show();
                feeder_id=feeder_id+userFDR.getInt(3);
                fdrCnt=fdrCnt+1;
                //  Toast.makeText(this,"NEXT",Toast.LENGTH_LONG).show();
            }
            while (userFDR.moveToNext());
        }
        //  String u= userCnt.getString(0);
        if(fdrCnt > 0 )
            return feeder_id;
        else
            return  feeder_id;

    }


    public Cursor getUserFeeder(String user_name ) {
        SQLiteDatabase database = this.getWritableDatabase();
        String whereClause = "USER_NAME"+" = "+user_name+" ";
        String st=user_name;
        String[] cols={KEY_USER_NAME,KEY_USER_PASSWORD,KEY_FEEDER_NAME};
        String []selarg={st};
        //   Cursor c = database.query("FDR_TBL", new String[]{KEY_ID, KEY_FDR_ID, KEY_SUB_ID,KEY_POLE_TYP,KEY_SUPP_TYP,KEY_COND_TYP,KEY_DTR_CAP,KEY_AB_SWITCH,KEY_DTR_METERED,KEY_POLE_LAT,KEY_DPOLE_LONG,KEY_UPDATE}, KEY_UPDATE +"=?", selarg, null, null, null);

        Cursor c = database.query("USER_TBL", new String[] {KEY_USER_NAME,KEY_USER_PASSWORD,KEY_FEEDER_NAME,KEY_FDR_ID}, KEY_USER_NAME +"=?", selarg, null, null, null,null);
        if (c !=null ) {
            c.moveToFirst();
        }
        return c;
    }
    ///
    // User Management Sections
}
